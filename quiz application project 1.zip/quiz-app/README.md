# Full-Stack Quiz Application

A ready-to-run interactive quiz application built with:

- Frontend: React + Vite
- Backend: Spring Boot + Spring Security + JWT
- Database: MySQL + Spring Data JPA
- Authentication: JWT-based login with USER/ADMIN roles

## Features

### Student/User
- Register and login
- View available quizzes
- Start a quiz
- Answer multiple-choice questions
- Submit quiz
- See score and percentage
- Review each question with selected answer and correct answer
- View previous attempts

### Admin
- Secure admin login
- Dashboard with quiz/question counts
- Create quizzes
- Add questions and four options
- Mark the correct option
- Edit/delete questions
- Delete quizzes

## Prerequisites

Install:
- Java 17+
- Maven 3.9+
- Node.js 20+
- MySQL 8+

## 1. Database

Create a MySQL database:

```sql
CREATE DATABASE quiz_app;
```

The backend automatically creates/updates tables using Hibernate.

Default database settings in `backend/src/main/resources/application.properties`:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/quiz_app
spring.datasource.username=root
spring.datasource.password=root
```

Change the username/password if your MySQL installation is different.

## 2. Start Backend

```bash
cd backend
mvn spring-boot:run
```

Backend:
http://localhost:8080

## 3. Start Frontend

Open another terminal:

```bash
cd frontend
npm install
npm run dev
```

Frontend:
http://localhost:5173

## Demo accounts

The application creates an admin account automatically on first backend startup:

- Email: admin@quizapp.com
- Password: Admin@123

You can also register normal users from the Register page.

For production, change the demo admin password and JWT secret.

## API Overview

### Authentication
- POST `/api/auth/register`
- POST `/api/auth/login`

### Quizzes
- GET `/api/quizzes`
- GET `/api/quizzes/{id}`
- POST `/api/quizzes` (ADMIN)
- PUT `/api/quizzes/{id}` (ADMIN)
- DELETE `/api/quizzes/{id}` (ADMIN)

### Questions
- POST `/api/quizzes/{quizId}/questions` (ADMIN)
- PUT `/api/questions/{id}` (ADMIN)
- DELETE `/api/questions/{id}` (ADMIN)

### Attempts
- POST `/api/quizzes/{quizId}/attempts`
- GET `/api/attempts/my`
- GET `/api/attempts/{id}`

## Project Structure

```text
quiz-app/
├── backend/
│   ├── pom.xml
│   └── src/main/java/com/quizapp/
│       ├── QuizApplication.java
│       ├── config/
│       ├── controller/
│       ├── dto/
│       ├── entity/
│       ├── repository/
│       ├── security/
│       └── service/
├── frontend/
│   ├── package.json
│   ├── vite.config.js
│   └── src/
│       ├── api.js
│       ├── App.jsx
│       ├── main.jsx
│       └── styles.css
└── README.md
```

## Production checklist

- Replace the JWT secret with a long random secret stored as an environment variable.
- Use HTTPS.
- Do not use the demo admin password.
- Configure CORS for the real frontend domain.
- Use database migrations such as Flyway for production.
- Add rate limiting and account lockout for public deployments.
