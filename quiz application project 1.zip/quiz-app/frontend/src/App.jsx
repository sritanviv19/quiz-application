import React, {useEffect, useState} from 'react'
import {Routes, Route, Link, useNavigate, useParams} from 'react-router-dom'
import api from './api'

function Layout({children}) {
  const nav=useNavigate()
  const user=JSON.parse(localStorage.getItem('user')||'null')
  const logout=()=>{localStorage.clear();nav('/login')}
  return <div className="app">
    <nav className="nav">
      <Link className="brand" to="/">QuizMaster</Link>
      <div>
        {user ? <>
          <Link to="/attempts">My Attempts</Link>
          {user.role==='ADMIN' && <Link to="/admin">Admin</Link>}
          <span className="user">{user.name}</span>
          <button className="linkBtn" onClick={logout}>Logout</button>
        </> : <><Link to="/login">Login</Link><Link to="/register">Register</Link></>}
      </div>
    </nav>
    <main className="container">{children}</main>
  </div>
}

function Home(){
  const [quizzes,setQuizzes]=useState([])
  useEffect(()=>{api.get('/quizzes').then(r=>setQuizzes(r.data))},[])
  return <><section className="hero"><h1>Challenge your knowledge.</h1><p>Take interactive quizzes, get instant scores and review your performance.</p></section>
    <div className="grid">{quizzes.map(q=><div className="card" key={q.id}><h2>{q.title}</h2><p>{q.description}</p><p>{q.questions.length} questions</p><Link className="btn" to={`/quiz/${q.id}`}>Start Quiz</Link></div>)}</div>
  </>
}

function Login(){
  const nav=useNavigate(); const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [error,setError]=useState('')
  const submit=async e=>{e.preventDefault();try{const r=await api.post('/auth/login',{email,password});localStorage.setItem('token',r.data.token);localStorage.setItem('user',JSON.stringify(r.data));nav('/')}catch(x){setError(x.response?.data||'Login failed')}}
  return <AuthForm title="Welcome back" onSubmit={submit} error={error}>
    <input placeholder="Email" type="email" value={email} onChange={e=>setEmail(e.target.value)} required/>
    <input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} required/>
  </AuthForm>
}

function Register(){
  const nav=useNavigate(); const [form,setForm]=useState({name:'',email:'',password:''}); const [error,setError]=useState('')
  const submit=async e=>{e.preventDefault();try{const r=await api.post('/auth/register',form);localStorage.setItem('token',r.data.token);localStorage.setItem('user',JSON.stringify(r.data));nav('/')}catch(x){setError(x.response?.data||'Registration failed')}}
  return <AuthForm title="Create account" onSubmit={submit} error={error}>
    <input placeholder="Full name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} required/>
    <input placeholder="Email" type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} required/>
    <input placeholder="Password (6+ characters)" type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} minLength="6" required/>
  </AuthForm>
}

function AuthForm({title,onSubmit,error,children}){
  return <div className="auth card"><h1>{title}</h1>{error&&<div className="error">{error}</div>}<form onSubmit={onSubmit}>{children}<button className="btn">Continue</button></form></div>
}

function Quiz(){
  const {id}=useParams(); const nav=useNavigate(); const [quiz,setQuiz]=useState(null); const [answers,setAnswers]=useState({}); const [loading,setLoading]=useState(true)
  useEffect(()=>{api.get(`/quizzes/${id}`).then(r=>setQuiz(r.data)).finally(()=>setLoading(false))},[id])
  if(loading)return <p>Loading...</p>
  if(!quiz)return <p>Quiz not found.</p>
  const submit=async()=>{if(Object.keys(answers).length<quiz.questions.length && !confirm('Some questions are unanswered. Submit anyway?'))return
    const r=await api.post(`/quizzes/${id}/attempts`,{answers:Object.entries(answers).map(([questionId,selectedOption])=>({questionId:Number(questionId),selectedOption}))})
    nav(`/result/${r.data.id}`,{state:r.data})
  }
  return <div><h1>{quiz.title}</h1><p>{quiz.description}</p>
    {quiz.questions.map((q,i)=><div className="question card" key={q.id}><h3>{i+1}. {q.questionText}</h3>
      {['A','B','C','D'].map(k=><label className="option" key={k}><input type="radio" name={`q${q.id}`} checked={answers[q.id]===k} onChange={()=>setAnswers({...answers,[q.id]:k})}/><b>{k}.</b> {q['option'+k]}</label>)}
    </div>)}
    <button className="btn wide" onClick={submit}>Submit Quiz</button>
  </div>
}

function Result(){
  const {id}=useParams(); const [data,setData]=useState(null)
  useEffect(()=>{api.get(`/attempts/${id}`).then(r=>setData(r.data))},[id])
  if(!data)return <p>Loading result...</p>
  const pct=data.totalQuestions?Math.round(data.score/data.totalQuestions*100):0
  return <div className="result card"><h1>Quiz Complete 🎉</h1><div className="score">{pct}%</div><h2>{data.score} / {data.totalQuestions}</h2><p>{data.quiz}</p><h3>Answer Review</h3>
    {data.questions.map((q,i)=><div className="review" key={q.id}><b>{i+1}. {q.questionText}</b><span>Correct answer: {q.correctOption}</span></div>)}
    <Link className="btn" to="/">Back to Quizzes</Link>
  </div>
}

function Attempts(){
  const [rows,setRows]=useState([])
  useEffect(()=>{api.get('/attempts/my').then(r=>setRows(r.data))},[])
  return <><h1>My Attempts</h1><div className="card tableWrap"><table><thead><tr><th>Quiz</th><th>Score</th><th>Percentage</th><th>Date</th><th></th></tr></thead><tbody>{rows.map(a=><tr key={a.id}><td>{a.quizTitle}</td><td>{a.score}/{a.totalQuestions}</td><td>{Math.round(a.percentage)}%</td><td>{new Date(a.submittedAt).toLocaleString()}</td><td><Link to={`/result/${a.id}`}>Review</Link></td></tr>)}</tbody></table></div></>
}

function Admin(){
  const [quizzes,setQuizzes]=useState([]); const [selected,setSelected]=useState(null); const [quizForm,setQuizForm]=useState({title:'',description:''})
  const [qForm,setQForm]=useState({questionText:'',optionA:'',optionB:'',optionC:'',optionD:'',correctOption:'A'})
  const load=()=>api.get('/quizzes').then(r=>setQuizzes(r.data)); useEffect(load,[])
  const createQuiz=async e=>{e.preventDefault();await api.post('/quizzes',quizForm);setQuizForm({title:'',description:''});load()}
  const addQuestion=async e=>{e.preventDefault();await api.post(`/quizzes/${selected.id}/questions`,qForm);setQForm({questionText:'',optionA:'',optionB:'',optionC:'',optionD:'',correctOption:'A'});load().then(()=>api.get(`/quizzes/${selected.id}`).then(r=>setSelected(r.data)))}
  const delQuiz=async id=>{if(confirm('Delete quiz?')){await api.delete(`/quizzes/${id}`);setSelected(null);load()}}
  const delQ=async id=>{await api.delete(`/questions/${id}`);api.get(`/quizzes/${selected.id}`).then(r=>setSelected(r.data));load()}
  return <><h1>Admin Dashboard</h1><div className="adminGrid"><div className="card"><h2>Create Quiz</h2><form onSubmit={createQuiz}><input placeholder="Title" value={quizForm.title} onChange={e=>setQuizForm({...quizForm,title:e.target.value})} required/><textarea placeholder="Description" value={quizForm.description} onChange={e=>setQuizForm({...quizForm,description:e.target.value})}/><button className="btn">Create</button></form><hr/><h2>Quizzes</h2>{quizzes.map(q=><div className="adminRow" key={q.id}><button onClick={()=>setSelected(q)}>{q.title}</button><button className="danger" onClick={()=>delQuiz(q.id)}>Delete</button></div>)}</div>
  {selected&&<div className="card"><h2>Add question to: {selected.title}</h2><form onSubmit={addQuestion}><textarea placeholder="Question" value={qForm.questionText} onChange={e=>setQForm({...qForm,questionText:e.target.value})} required/>{['A','B','C','D'].map(k=><input key={k} placeholder={`Option ${k}`} value={qForm['option'+k]} onChange={e=>setQForm({...qForm,['option'+k]:e.target.value})} required/>)}<select value={qForm.correctOption} onChange={e=>setQForm({...qForm,correctOption:e.target.value})}><option>A</option><option>B</option><option>C</option><option>D</option></select><button className="btn">Add Question</button></form><hr/><h2>Questions</h2>{selected.questions.map((q,i)=><div className="adminQuestion" key={q.id}><span>{i+1}. {q.questionText}</span><button className="danger" onClick={()=>delQ(q.id)}>Delete</button></div>)}</div>}</div></>
}

function Protected({admin=false,children}){
  const user=JSON.parse(localStorage.getItem('user')||'null'); const nav=useNavigate()
  useEffect(()=>{if(!user || (admin&&user.role!=='ADMIN'))nav('/login')},[])
  return user&&( !admin || user.role==='ADMIN')?children:null
}

export default function App(){
  return <Layout><Routes>
    <Route path="/" element={<Home/>}/><Route path="/login" element={<Login/>}/><Route path="/register" element={<Register/>}/>
    <Route path="/quiz/:id" element={<Protected><Quiz/></Protected>}/>
    <Route path="/result/:id" element={<Protected><Result/></Protected>}/>
    <Route path="/attempts" element={<Protected><Attempts/></Protected>}/>
    <Route path="/admin" element={<Protected admin><Admin/></Protected>}/>
  </Routes></Layout>
}
