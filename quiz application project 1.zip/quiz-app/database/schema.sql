CREATE DATABASE IF NOT EXISTS quiz_app;
USE quiz_app;

-- Tables are created automatically by Spring Boot/JPA.
-- This file is intentionally minimal so the application can evolve its schema.
