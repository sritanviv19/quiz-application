package com.quizapp.dto;

import java.util.List;

public class QuizDtos {
    public record QuestionResponse(Long id, String questionText, String optionA, String optionB,
                                   String optionC, String optionD) {}
    public record QuizResponse(Long id, String title, String description, List<QuestionResponse> questions) {}
    public record QuizRequest(String title, String description) {}
    public record QuestionRequest(String questionText, String optionA, String optionB,
                                  String optionC, String optionD, String correctOption) {}
    public record AttemptRequest(List<Answer> answers) {}
    public record Answer(Long questionId, String selectedOption) {}
    public record AttemptResponse(Long id, Long quizId, String quizTitle, int score,
                                  int totalQuestions, double percentage, String submittedAt) {}
}
