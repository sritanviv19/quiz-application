package com.quizapp.entity;
public enum Role { USER, ADMIN }
