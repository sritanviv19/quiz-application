package com.quizapp.repository;
import com.quizapp.entity.Attempt;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
public interface AttemptRepository extends JpaRepository<Attempt, Long> {
    List<Attempt> findByUserIdOrderBySubmittedAtDesc(Long userId);
}
