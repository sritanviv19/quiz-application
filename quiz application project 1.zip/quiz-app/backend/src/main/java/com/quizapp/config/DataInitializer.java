package com.quizapp.config;

import com.quizapp.entity.*;
import com.quizapp.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.*;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataInitializer {
    @Bean
    CommandLineRunner init(UserRepository users, QuizRepository quizzes,
                           QuestionRepository questions, PasswordEncoder encoder) {
        return args -> {
            if (!users.existsByEmail("admin@quizapp.com")) {
                users.save(User.builder()
                    .name("Quiz Admin")
                    .email("admin@quizapp.com")
                    .password(encoder.encode("Admin@123"))
                    .role(Role.ADMIN).build());
            }

            if (quizzes.count() == 0) {
                Quiz quiz = quizzes.save(Quiz.builder()
                    .title("Java Basics")
                    .description("Test your knowledge of core Java concepts.")
                    .build());

                questions.save(Question.builder()
                    .quiz(quiz)
                    .questionText("Which keyword is used to inherit a class in Java?")
                    .optionA("implements").optionB("extends").optionC("inherits").optionD("super")
                    .correctOption("B").build());

                questions.save(Question.builder()
                    .quiz(quiz)
                    .questionText("Which method is the entry point of a Java application?")
                    .optionA("start()").optionB("run()").optionC("main()").optionD("init()")
                    .correctOption("C").build());

                questions.save(Question.builder()
                    .quiz(quiz)
                    .questionText("Which collection does not allow duplicate elements?")
                    .optionA("List").optionB("Set").optionC("ArrayList").optionD("Vector")
                    .correctOption("B").build());
            }
        };
    }
}
