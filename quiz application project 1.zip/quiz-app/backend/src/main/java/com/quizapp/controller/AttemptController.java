package com.quizapp.controller;

import com.quizapp.dto.QuizDtos.*;
import com.quizapp.repository.*;
import org.springframework.http.*;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/attempts")
public class AttemptController {
    private final AttemptRepository attempts;
    private final UserRepository users;
    private final QuestionRepository questions;

    public AttemptController(AttemptRepository attempts, UserRepository users, QuestionRepository questions) {
        this.attempts=attempts; this.users=users; this.questions=questions;
    }

    @GetMapping("/my")
    public List<AttemptResponse> myAttempts() {
        var user=users.findByEmail(SecurityContextHolder.getContext().getAuthentication().getName()).orElseThrow();
        return attempts.findByUserIdOrderBySubmittedAtDesc(user.getId()).stream()
            .map(a -> new AttemptResponse(a.getId(),a.getQuiz().getId(),a.getQuiz().getTitle(),
                a.getScore(),a.getTotalQuestions(),
                a.getTotalQuestions()==0?0:a.getScore()*100.0/a.getTotalQuestions(),
                a.getSubmittedAt().toString())).toList();
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> get(@PathVariable Long id) {
        var user=users.findByEmail(SecurityContextHolder.getContext().getAuthentication().getName()).orElseThrow();
        var a=attempts.findById(id).orElse(null);
        if(a==null || !a.getUser().getId().equals(user.getId()))
            return ResponseEntity.notFound().build();
        var q=a.getQuiz().getQuestions().stream().map(x -> Map.of(
            "id", x.getId(), "questionText", x.getQuestionText(),
            "correctOption", x.getCorrectOption()
        )).toList();
        return ResponseEntity.ok(Map.of("attempt", a.getId(), "quiz", a.getQuiz().getTitle(),
            "score", a.getScore(), "totalQuestions", a.getTotalQuestions(),
            "questions", q));
    }
}
