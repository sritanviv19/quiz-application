package com.quizapp.controller;

import com.quizapp.dto.AuthDtos.*;
import com.quizapp.entity.*;
import com.quizapp.repository.UserRepository;
import com.quizapp.security.JwtService;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final JwtService jwt;

    public AuthController(UserRepository users, PasswordEncoder encoder, JwtService jwt) {
        this.users = users; this.encoder = encoder; this.jwt = jwt;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody @Valid RegisterRequest r) {
        if (r.name() == null || r.email() == null || r.password() == null ||
            r.name().isBlank() || r.email().isBlank() || r.password().length() < 6)
            return ResponseEntity.badRequest().body("Name, email and password (6+ chars) are required.");
        if (users.existsByEmail(r.email().toLowerCase()))
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Email already registered.");

        User u = users.save(User.builder()
            .name(r.name().trim()).email(r.email().toLowerCase().trim())
            .password(encoder.encode(r.password())).role(Role.USER).build());

        return ResponseEntity.ok(response(u));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest r) {
        var user = users.findByEmail(r.email().toLowerCase().trim()).orElse(null);
        if (user == null || !encoder.matches(r.password(), user.getPassword()))
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid email or password.");
        return ResponseEntity.ok(response(user));
    }

    private AuthResponse response(User u) {
        return new AuthResponse(jwt.generate(u.getEmail(), u.getRole().name(), u.getId(), u.getName()),
                u.getId(), u.getName(), u.getEmail(), u.getRole().name());
    }
}
