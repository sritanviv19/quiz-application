package com.quizapp.controller;

import com.quizapp.dto.QuizDtos.*;
import com.quizapp.entity.*;
import com.quizapp.repository.*;
import org.springframework.http.*;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.*;

@RestController
@RequestMapping("/api")
public class QuizController {
    private final QuizRepository quizzes;
    private final QuestionRepository questions;
    private final UserRepository users;
    private final AttemptRepository attempts;

    public QuizController(QuizRepository quizzes, QuestionRepository questions,
                          UserRepository users, AttemptRepository attempts) {
        this.quizzes=quizzes; this.questions=questions; this.users=users; this.attempts=attempts;
    }

    @GetMapping("/quizzes")
    public List<QuizResponse> all() {
        return quizzes.findAll().stream().map(this::toResponse).toList();
    }

    @GetMapping("/quizzes/{id}")
    public ResponseEntity<?> get(@PathVariable Long id) {
        return quizzes.findById(id).map(q -> ResponseEntity.ok(toResponse(q)))
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/quizzes")
    public QuizResponse create(@RequestBody QuizRequest r) {
        return toResponse(quizzes.save(Quiz.builder().title(r.title()).description(r.description()).build()));
    }

    @PutMapping("/quizzes/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody QuizRequest r) {
        var q = quizzes.findById(id).orElse(null);
        if(q==null) return ResponseEntity.notFound().build();
        q.setTitle(r.title()); q.setDescription(r.description());
        return ResponseEntity.ok(toResponse(quizzes.save(q)));
    }

    @DeleteMapping("/quizzes/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        if(!quizzes.existsById(id)) return ResponseEntity.notFound().build();
        quizzes.deleteById(id); return ResponseEntity.noContent().build();
    }

    @PostMapping("/quizzes/{quizId}/questions")
    public ResponseEntity<?> addQuestion(@PathVariable Long quizId, @RequestBody QuestionRequest r) {
        var quiz=quizzes.findById(quizId).orElse(null);
        if(quiz==null) return ResponseEntity.notFound().build();
        if(!Set.of("A","B","C","D").contains(r.correctOption()))
            return ResponseEntity.badRequest().body("correctOption must be A, B, C or D.");
        var q=questions.save(Question.builder().quiz(quiz).questionText(r.questionText())
            .optionA(r.optionA()).optionB(r.optionB()).optionC(r.optionC()).optionD(r.optionD())
            .correctOption(r.correctOption()).build());
        return ResponseEntity.ok(q.getId());
    }

    @PutMapping("/questions/{id}")
    public ResponseEntity<?> updateQuestion(@PathVariable Long id, @RequestBody QuestionRequest r) {
        var q=questions.findById(id).orElse(null);
        if(q==null) return ResponseEntity.notFound().build();
        q.setQuestionText(r.questionText()); q.setOptionA(r.optionA()); q.setOptionB(r.optionB());
        q.setOptionC(r.optionC()); q.setOptionD(r.optionD()); q.setCorrectOption(r.correctOption());
        questions.save(q); return ResponseEntity.ok().build();
    }

    @DeleteMapping("/questions/{id}")
    public ResponseEntity<?> deleteQuestion(@PathVariable Long id) {
        if(!questions.existsById(id)) return ResponseEntity.notFound().build();
        questions.deleteById(id); return ResponseEntity.noContent().build();
    }

    @PostMapping("/quizzes/{quizId}/attempts")
    public ResponseEntity<?> submit(@PathVariable Long quizId, @RequestBody AttemptRequest req) {
        String email=SecurityContextHolder.getContext().getAuthentication().getName();
        User user=users.findByEmail(email).orElseThrow();
        Quiz quiz=quizzes.findById(quizId).orElse(null);
        if(quiz==null) return ResponseEntity.notFound().build();

        Map<Long,String> submitted=new HashMap<>();
        if(req.answers()!=null) req.answers().forEach(a -> submitted.put(a.questionId(), a.selectedOption()));

        int score=0;
        for(Question q: quiz.getQuestions()) {
            if(q.getCorrectOption().equalsIgnoreCase(submitted.getOrDefault(q.getId(), ""))) score++;
        }

        Attempt attempt=attempts.save(Attempt.builder().user(user).quiz(quiz).score(score)
            .totalQuestions(quiz.getQuestions().size()).submittedAt(LocalDateTime.now()).build());

        return ResponseEntity.ok(new AttemptResponse(attempt.getId(), quiz.getId(), quiz.getTitle(),
            score, quiz.getQuestions().size(),
            quiz.getQuestions().isEmpty()?0:(score*100.0/quiz.getQuestions().size()),
            attempt.getSubmittedAt().toString()));
    }

    private QuizResponse toResponse(Quiz q) {
        return new QuizResponse(q.getId(), q.getTitle(), q.getDescription(),
            q.getQuestions().stream().map(x -> new QuestionResponse(x.getId(),x.getQuestionText(),
                x.getOptionA(),x.getOptionB(),x.getOptionC(),x.getOptionD())).toList());
    }
}
